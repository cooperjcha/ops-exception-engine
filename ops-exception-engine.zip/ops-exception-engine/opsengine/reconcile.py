"""Reconcile what the timecard says against what the scan activity shows.

Two systems describe the same shift. When they disagree, someone either has a pay or
compliance problem (a meal that wasn't recorded, work off the clock) or an operational
one (a long unexplained idle gap). Each rule below emits one exception row.
"""
from __future__ import annotations

import pandas as pd

from . import config as C

SEVERITY_ORDER = {"High": 0, "Medium": 1, "Low": 2}


def _gaps(active: pd.Series, lo: pd.Timestamp, hi: pd.Timestamp, min_minutes: int) -> list[tuple]:
    """Stretches with no scan activity inside [lo, hi], at least min_minutes long."""
    m = active[(active >= lo) & (active <= hi)].sort_values()
    if m.empty:
        return [(lo, hi)] if (hi - lo).total_seconds() / 60 >= min_minutes else []
    gaps = []
    prev = m.iloc[0]
    for t in m.iloc[1:]:
        if (t - prev).total_seconds() / 60 - 1 >= min_minutes:
            gaps.append((prev + pd.Timedelta(minutes=1), t))
        prev = t
    return gaps


def _overlap_min(a: tuple, b: tuple) -> float:
    s, e = max(a[0], b[0]), min(a[1], b[1])
    return max(0.0, (e - s).total_seconds() / 60)


def _fmt(t: pd.Timestamp) -> str:
    return t.strftime("%H:%M")


def reconcile_shift(login: str, shift_date: str, segs: pd.DataFrame, active: pd.Series) -> list[dict]:
    out = []

    def add(rule, severity, minutes, detail, when):
        out.append({"login": login, "shift_date": shift_date, "rule": rule, "severity": severity,
                    "minutes": round(float(minutes)), "when": when, "detail": detail})

    start, end = segs.start.min(), segs.end.max()
    shift_hours = (end - start).total_seconds() / 3600
    meals = [(r.start, r.end) for r in segs[segs.segment_type == "meal"].itertuples()]
    gaps = _gaps(active, start + pd.Timedelta(minutes=10), end - pd.Timedelta(minutes=5), C.IDLE_GAP_MINUTES)
    explained = set()

    if not meals and shift_hours > C.MEAL_REQUIRED_AFTER_HOURS:
        long_gaps = [g for g in gaps if (g[1] - g[0]).total_seconds() / 60 >= C.UNRECORDED_MEAL_GAP_MINUTES]
        if long_gaps:
            g = max(long_gaps, key=lambda g: g[1] - g[0])
            explained.add(g)
            add("Unrecorded meal", "High", (g[1] - g[0]).total_seconds() / 60,
                "No meal on the timecard, but scan activity stops long enough to be one. Timecard likely needs a meal punch.",
                f"{_fmt(g[0])}-{_fmt(g[1])}")
        else:
            add("Missed meal", "High", 0,
                f"Shift ran {shift_hours:.1f}h with no meal punch and no break visible in activity.",
                f"{_fmt(start)}-{_fmt(end)}")

    for m in meals:
        dur = (m[1] - m[0]).total_seconds() / 60
        when = f"{_fmt(m[0])}-{_fmt(m[1])}"
        if dur < C.MEAL_MIN_MINUTES:
            add("Short meal", "Medium", dur, f"Meal recorded as {dur:.0f} min; minimum is {C.MEAL_MIN_MINUTES}.", when)
        hrs_in = (m[0] - start).total_seconds() / 3600
        if hrs_in > C.MEAL_LATEST_START_HOURS:
            add("Late meal", "Medium", (hrs_in - C.MEAL_LATEST_START_HOURS) * 60,
                f"Meal started {hrs_in:.1f}h into the shift; limit is {C.MEAL_LATEST_START_HOURS:.0f}h.", when)
        for g in gaps:
            if _overlap_min(g, m) >= 0.5 * dur:
                explained.add(g)
        busy = int(((active >= m[0]) & (active < m[1])).sum())
        if busy >= C.ACTIVITY_IN_MEAL_MINUTES:
            # look for the break they actually took: an unexplained gap of similar length
            real = [g for g in gaps if g not in explained and (g[1] - g[0]).total_seconds() / 60 >= 0.6 * dur]
            where = "The real break was probably taken at another time."
            if real:
                g = min(real, key=lambda g: abs((g[0] - m[0]).total_seconds()))
                explained.add(g)
                where = f"Activity shows the break was actually {_fmt(g[0])}-{_fmt(g[1])}; the punch needs correcting."
            add("Activity during recorded meal", "High", busy,
                f"{busy} active minutes during the punched meal. {where}", when)

    for g in gaps:
        if g in explained:
            continue
        mins = (g[1] - g[0]).total_seconds() / 60
        add("Unexplained idle gap", "Medium" if mins >= 30 else "Low", mins,
            "Paid time with no scan activity and nothing on the timecard to explain it.", f"{_fmt(g[0])}-{_fmt(g[1])}")

    off = active[(active < start) | (active >= end)]
    if len(off) >= C.OFF_CLOCK_MINUTES:
        add("Activity off the clock", "High", len(off),
            f"{len(off)} active minutes outside punched time. Possible unpaid work.",
            f"{_fmt(off.min())}-{_fmt(off.max())}")
    return out


def reconcile(timecards: pd.DataFrame, activity: pd.DataFrame, roster: pd.DataFrame | None = None) -> pd.DataFrame:
    tc = timecards.copy()
    tc["start"], tc["end"] = pd.to_datetime(tc.start), pd.to_datetime(tc.end)
    act = activity.copy()
    act["minute"] = pd.to_datetime(act.minute)
    act = act[act.units > 0]
    by_login = {k: g.minute for k, g in act.groupby("login")}

    rows = []
    for (login, day), segs in tc.groupby(["login", "shift_date"]):
        mins = by_login.get(login, pd.Series(dtype="datetime64[ns]"))
        # only activity near this shift (shifts cross midnight, so filter by time window, not date)
        lo, hi = segs.start.min() - pd.Timedelta(hours=2), segs.end.max() + pd.Timedelta(hours=2)
        rows += reconcile_shift(login, str(day), segs, mins[(mins >= lo) & (mins <= hi)])

    cols = ["login", "shift_date", "rule", "severity", "minutes", "when", "detail"]
    ex = pd.DataFrame(rows, columns=cols)
    if roster is not None and not ex.empty:
        ex = ex.merge(roster[["login", "name", "manager"]], on="login", how="left")
    if ex.empty:
        return ex
    ex["_s"] = ex.severity.map(SEVERITY_ORDER)
    return ex.sort_values(["_s", "minutes"], ascending=[True, False]).drop(columns="_s").reset_index(drop=True)
