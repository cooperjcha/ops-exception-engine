"""Ops Exception Engine: turn raw operations exports into a ranked list of things a manager should act on."""

__version__ = "1.0.0"
