"""Every tunable threshold lives here so the rules are visible and reviewable in one place."""

# Process checklist used by floor auditors. Keys are the column names in audits.csv.
CHECKS = {
    "chk_ready_stance": "Ready stance facing the shelf",
    "chk_confirm_bin": "Reads screen and confirms bin before reaching",
    "chk_retrieve_2s": "Retrieves item from bin in 2s or less",
    "chk_place_2s": "Places item and confirms in 2s or less",
    "chk_multi_scan": "Scans multi-quantity items once",
    "chk_tote_swap": "Swaps tote only when prompted",
}

# What a manager should try when an associate fails a given check.
COACHING_TIPS = {
    "chk_ready_stance": "Reset the starting position: feet set, square to the shelf, so the first reach needs no turn.",
    "chk_confirm_bin": "Have them read the bin label out loud for a few picks; it breaks the habit of reaching before confirming.",
    "chk_retrieve_2s": "Watch the hand path: one reach in, one pull out. Searching inside the bin is usually the hidden time.",
    "chk_place_2s": "Pre-position the tote so placing is a single motion with no repositioning before the confirm.",
    "chk_multi_scan": "Show the quantity prompt on screen; scanning each unit separately adds seconds on every multi-unit pick.",
    "chk_tote_swap": "Walk through the swap prompt together; early swaps add a full walk cycle each time.",
}

SEEK_TO_UNDERSTAND = (
    "Passed every check but is still slow, so the checklist isn't finding the cause. "
    "Ask directly what is slowing them down and look outside the checklist: item mix, station layout, equipment, fatigue."
)
FIRST_CONVERSATION = (
    "No audit on file this week. Open with a low-pressure check-in, then schedule an audit to find the cause."
)

# Coaching queue
MIN_HOURS = 10                 # ignore associates with too little time to judge
FLAG_PERCENTILE = 0.80         # slower than 80% of the site gets flagged
REPEAT_WEIGHT = 15             # priority points per consecutive prior week flagged
NO_AUDIT_WEIGHT = 10
FAILED_CHECK_WEIGHT = 5

# Timecard reconciliation
MEAL_REQUIRED_AFTER_HOURS = 6.0
MEAL_MIN_MINUTES = 30
MEAL_LATEST_START_HOURS = 5.0  # meal must start within 5h of shift start
IDLE_GAP_MINUTES = 20          # gap in scan activity worth explaining
UNRECORDED_MEAL_GAP_MINUTES = 25
ACTIVITY_IN_MEAL_MINUTES = 3   # active minutes inside a recorded meal before we flag it
OFF_CLOCK_MINUTES = 2          # active minutes outside punched time before we flag it
