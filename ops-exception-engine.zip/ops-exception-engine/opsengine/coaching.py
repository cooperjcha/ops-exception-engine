"""Weekly coaching queue: who is slow, why (according to audits), and who to talk to first."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from . import config as C


# ---------- history (who was flagged in earlier weeks, and why) ----------

def load_history(path: Path) -> dict:
    if path.exists():
        return json.loads(path.read_text())
    return {}


def save_history(path: Path, history: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(history, indent=2, sort_keys=True))


def consecutive_prior_weeks(history: dict, login: str, week: int) -> int:
    n, w = 0, week - 1
    while str(w) in history and login in history[str(w)]:
        n += 1
        w -= 1
    return n


# ---------- core weekly build ----------

def latest_audit(audits: pd.DataFrame | None, week: int) -> pd.DataFrame:
    """Most recent audit per login within the week (empty frame if no audit data)."""
    cols = ["login", "audit_id", "created_at", *C.CHECKS]
    if audits is None or audits.empty:
        return pd.DataFrame(columns=cols)
    a = audits[audits.week == week].copy()
    a["created_at"] = pd.to_datetime(a["created_at"])
    return a.sort_values("created_at").groupby("login", as_index=False).last()[cols]


def build_week(prod: pd.DataFrame, roster: pd.DataFrame, audits: pd.DataFrame | None,
               week: int, history: dict) -> tuple[pd.DataFrame, dict]:
    """Return (coaching queue for the week, summary stats)."""
    wk = prod[prod.week == week].drop_duplicates(["week", "login"])
    wk = wk.merge(roster[["login", "name", "manager", "status"]], on="login", how="left")
    eligible = wk[(wk.hours >= C.MIN_HOURS) & (wk.status.fillna("").str.lower() == "active")]

    benchmark = float(eligible.avg_cycle_sec.median())
    threshold = float(eligible.avg_cycle_sec.quantile(C.FLAG_PERCENTILE))
    flagged = eligible[eligible.avg_cycle_sec >= threshold].copy()

    aud = latest_audit(audits, week)
    flagged = flagged.merge(aud, on="login", how="left")

    rows = []
    for _, r in flagged.iterrows():
        audited = pd.notna(r.get("audit_id"))
        failed = [k for k in C.CHECKS if audited and r[k] == "No"]
        if not audited:
            status, action, focus = "No audit", C.FIRST_CONVERSATION, None
        elif failed:
            focus = failed[0]
            status, action = "Failed checks", C.COACHING_TIPS[focus]
        else:
            status, action, focus = "Passed, still slow", C.SEEK_TO_UNDERSTAND, None

        prior = consecutive_prior_weeks(history, r.login, week)
        prev = history.get(str(week - 1), {}).get(r.login)
        same_reason = bool(prev and prev.get("status") == status and prev.get("focus") == focus)
        gap_pct = (r.avg_cycle_sec - benchmark) / benchmark * 100
        score = (gap_pct + C.REPEAT_WEIGHT * prior
                 + (C.NO_AUDIT_WEIGHT if not audited else 0) + C.FAILED_CHECK_WEIGHT * len(failed))
        rows.append({
            "login": r.login, "name": r["name"], "manager": r.manager,
            "avg_cycle_sec": round(r.avg_cycle_sec, 2), "vs_benchmark_sec": round(r.avg_cycle_sec - benchmark, 2),
            "hours": r.hours, "units": int(r.units), "idle_pct": round(r.idle_pct, 4),
            "status": status, "focus_check": C.CHECKS.get(focus, ""), "focus_key": focus or "",
            "failed_checks": [C.CHECKS[k] for k in failed], "action": action,
            "last_audit": "" if not audited else pd.Timestamp(r.created_at).strftime("%Y-%m-%d %H:%M"),
            "weeks_flagged_in_a_row": prior + 1, "repeat_same_reason": same_reason,
            "priority": round(score, 1),
        })
    queue = pd.DataFrame(rows).sort_values("priority", ascending=False).reset_index(drop=True)
    queue.insert(0, "rank", range(1, len(queue) + 1))

    # record this week so next week's run can see repeats
    history[str(week)] = {r.login: {"status": r.status, "focus": r.focus_key or None} for r in queue.itertuples()}

    audited_n = int((queue.status != "No audit").sum())
    summary = {
        "week": week, "benchmark_cycle_sec": round(benchmark, 2), "flag_threshold_sec": round(threshold, 2),
        "associates_evaluated": int(len(eligible)), "flagged": int(len(queue)),
        "audited": audited_n, "audit_coverage": round(audited_n / max(len(queue), 1), 3),
        "ready_to_coach": int((queue.status == "Failed checks").sum()),
        "seek_to_understand": int((queue.status == "Passed, still slow").sum()),
        "repeat_same_reason": int(queue.repeat_same_reason.sum()),
    }
    return queue, summary


def failure_rates(audits: pd.DataFrame | None, week: int, logins: list[str] | None = None) -> list[dict]:
    """Share of audits failing each check, for the flagged group and the whole site."""
    aud = latest_audit(audits, week)
    if aud.empty:
        return []
    out = []
    flagged = aud[aud.login.isin(logins)] if logins is not None else aud
    for k, label in C.CHECKS.items():
        out.append({
            "check": label, "key": k,
            "flagged_fail_rate": round(float((flagged[k] == "No").mean()), 3) if len(flagged) else 0.0,
            "site_fail_rate": round(float((aud[k] == "No").mean()), 3),
        })
    return sorted(out, key=lambda d: d["flagged_fail_rate"], reverse=True)


def weekly_trend(prod: pd.DataFrame, roster: pd.DataFrame, history: dict) -> list[dict]:
    active = set(roster[roster.status.str.lower() == "active"].login)
    out = []
    for w, g in prod.drop_duplicates(["week", "login"]).groupby("week"):
        g = g[(g.hours >= C.MIN_HOURS) & g.login.isin(active)]
        this_wk, last_wk = history.get(str(w), {}), history.get(str(w - 1), {})
        out.append({"week": int(w), "median_cycle_sec": round(float(g.avg_cycle_sec.median()), 2),
                    "flagged": len(this_wk), "repeat_flags": len(set(this_wk) & set(last_wk))})
    return out
