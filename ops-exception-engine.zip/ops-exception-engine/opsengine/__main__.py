"""Command line entry point.

    python -m opsengine generate              # write synthetic inputs to data/raw
    python -m opsengine build                 # run the pipeline on data/raw for the latest week
    python -m opsengine build --input path/to/exports --week 3
"""
from __future__ import annotations

import argparse
import shutil
import time
from pathlib import Path

import pandas as pd

from . import coaching, ingest, reconcile, report
from .generate import generate

ROOT = Path(__file__).resolve().parent.parent


def build(input_dir: Path, out_dir: Path, docs_dir: Path, week: int | None) -> dict:
    t0 = time.perf_counter()
    inputs = ingest.discover(input_dir)
    prod, roster = inputs["productivity"], inputs["roster"]
    audits = inputs.frames.get("audits")
    week = week or int(prod.week.max())

    # Replay every week up to the target so repeat flags are deterministic and the run is idempotent.
    history: dict = {}
    for w in sorted(int(x) for x in prod.week.unique() if x <= week):
        queue, summary = coaching.build_week(prod, roster, audits, w, history)
    coaching.save_history(out_dir / "history.json", history)

    focus = coaching.failure_rates(audits, week, list(queue[queue.status != "No audit"].login))
    trend = coaching.weekly_trend(prod[prod.week <= week], roster, history)
    issues = ingest.data_quality(inputs)

    if inputs.has("timecards") and inputs.has("activity"):
        exceptions = reconcile.reconcile(inputs["timecards"], inputs["activity"], roster)
    else:
        exceptions = pd.DataFrame(columns=["login", "shift_date", "rule", "severity", "minutes", "when", "detail"])
        print("  timecards/activity not found: skipping reconciliation")

    xlsx = out_dir / f"ops_tracker_week{week:02d}.xlsx"
    report.write_excel(xlsx, week, summary, queue, focus, exceptions, issues)

    payload = {
        "meta": {"site": "Harbor Point DC1 (fictional)", "week": week, "sources": inputs.sources,
                 "generated_in_sec": round(time.perf_counter() - t0, 2)},
        "summary": {**summary, "timecard_exceptions": int(len(exceptions)),
                    "timecard_high": int((exceptions.severity == "High").sum()) if len(exceptions) else 0,
                    "data_quality_issues": len(issues)},
        "focus": focus,
        "queue": queue.drop(columns=["focus_key"]).to_dict("records"),
        "exceptions": exceptions.fillna("").to_dict("records"),
        "data_quality": issues,
        "trend": trend,
        "managers": sorted(roster.manager.dropna().unique().tolist()),
    }
    report.write_dashboard_data(docs_dir, payload)
    shutil.copy(xlsx, docs_dir / "data" / "ops_tracker_latest.xlsx")  # downloadable from the live page

    s = payload["summary"]
    print(f"\nWeek {week}: {s['flagged']} flagged, {s['audited']} audited, "
          f"{s['timecard_exceptions']} timecard exceptions ({s['timecard_high']} high), "
          f"{s['data_quality_issues']} data quality issues")
    print(f"Wrote {xlsx.relative_to(ROOT) if xlsx.is_relative_to(ROOT) else xlsx}")
    print(f"Wrote {docs_dir / 'data' / 'dashboard.json'}  ({payload['meta']['generated_in_sec']}s)")
    return payload


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="opsengine", description="Turn ops exports into an exception queue.")
    sub = p.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("generate", help="write a synthetic dataset")
    g.add_argument("--out", type=Path, default=ROOT / "data" / "raw")
    g.add_argument("--seed", type=int, default=7)
    b = sub.add_parser("build", help="run the pipeline")
    b.add_argument("--input", type=Path, default=ROOT / "data" / "raw")
    b.add_argument("--out", type=Path, default=ROOT / "output")
    b.add_argument("--docs", type=Path, default=ROOT / "docs")
    b.add_argument("--week", type=int, default=None)
    args = p.parse_args(argv)

    if args.cmd == "generate":
        print(f"Synthetic data written to {generate(args.out, seed=args.seed)}")
    else:
        build(args.input, args.out, args.docs, args.week)


if __name__ == "__main__":
    main()
