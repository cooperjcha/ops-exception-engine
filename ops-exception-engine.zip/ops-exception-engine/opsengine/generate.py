"""Generate a fully synthetic dataset for a fictional fulfillment site.

Nothing here comes from a real company. Names, IDs, managers, rates and timecards are all
random draws, with known problems planted on purpose so the pipeline has something to find.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

from .config import CHECKS

FIRST = ["Ava", "Ben", "Carla", "Dev", "Elena", "Femi", "Gus", "Hana", "Ivan", "Jada", "Kofi", "Lena",
         "Marco", "Nia", "Omar", "Pia", "Quinn", "Rosa", "Sam", "Tara", "Uma", "Vic", "Wren", "Xavi",
         "Yara", "Zane", "Ines", "Joel", "Kira", "Luis", "Maya", "Noah", "Olga", "Raj", "Sita", "Theo"]
LAST = ["Alvarez", "Brooks", "Castillo", "Dimitrov", "Eze", "Fischer", "Garcia", "Hughes", "Ito", "Jensen",
        "Kowalski", "Lopez", "Mensah", "Nguyen", "Ortiz", "Patel", "Quist", "Rossi", "Silva", "Tanaka",
        "Usman", "Varga", "Walsh", "Yilmaz", "Zhou"]
MANAGERS = ["Okafor, Dana", "Lindqvist, Mateo", "Reyes, Priya", "Chen, Walter", "Abara, Sofia"]
AUDITORS = ["auditor01", "auditor02", "auditor03", "auditor04"]

SHIFT_START = 18  # 18:00 night shift crossing midnight
SHIFT_HOURS = 10.5


def make_roster(rng: np.random.Generator, n: int = 60) -> pd.DataFrame:
    rows, logins = [], set()
    while len(rows) < n:
        first, last = rng.choice(FIRST), rng.choice(LAST)
        login = (first[:4] + last[:4]).lower()
        if login in logins:
            continue
        logins.add(login)
        rows.append({
            "associate_id": int(rng.integers(1_000_000, 9_999_999)),
            "login": login,
            "name": f"{last}, {first}",
            "manager": MANAGERS[len(rows) % len(MANAGERS)],
            "shift": "Night",
            "status": "Active",
            "hire_date": (date(2025, 1, 1) + timedelta(days=int(rng.integers(0, 520)))).isoformat(),
        })
    roster = pd.DataFrame(rows)
    roster.loc[n - 1, "status"] = "Terminated"  # planted: terminated but still logging hours
    return roster


def _latent_profiles(rng: np.random.Generator, roster: pd.DataFrame) -> pd.DataFrame:
    """Hidden 'truth' for each associate that drives every other table."""
    check_keys = list(CHECKS)
    p = roster[["login"]].copy()
    p["base_cycle"] = np.clip(rng.normal(11.5, 1.4, len(p)), 8.5, 16)
    struggling = rng.random(len(p)) < 0.22
    p.loc[struggling, "base_cycle"] += rng.uniform(3, 7, struggling.sum())
    # Most strugglers have a checklist weakness; some don't (the checklist can't explain them).
    p["weakness"] = None
    for i in np.where(struggling)[0]:
        if rng.random() < 0.75:
            p.at[i, "weakness"] = rng.choice(check_keys, p=[.1, .15, .3, .2, .15, .1])
    p["trend"] = rng.normal(0, 0.6, len(p))  # seconds per week drift
    return p


def make_productivity(rng, roster, profiles, weeks) -> pd.DataFrame:
    rows = []
    for w in weeks:
        for _, a in profiles.iterrows():
            hours = round(float(rng.uniform(18, 40)), 2)
            cycle = max(7.5, a.base_cycle + a.trend * w + rng.normal(0, 1.4))
            idle = float(np.clip(rng.beta(2, 14) + (0.04 if cycle > 15 else 0), 0.02, 0.4))
            units = int(hours * 3600 * (1 - idle) / cycle)
            rows.append({"week": w, "login": a.login, "units": units, "hours": hours,
                         "avg_cycle_sec": round(cycle, 2), "idle_pct": round(idle, 4)})
    # planted: two logins that don't exist on the roster
    for ghost in ("tempx001", "tempx002"):
        rows.append({"week": weeks[-1], "login": ghost, "units": 2100, "hours": 22.0,
                     "avg_cycle_sec": 12.9, "idle_pct": 0.11})
    # planted: a duplicate row
    rows.append(dict(rows[5]))
    return pd.DataFrame(rows)


def make_audits(rng, roster, profiles, weeks) -> pd.DataFrame:
    rows = []
    start = date(2026, 6, 29)
    for w in weeks:
        for _, a in profiles.iterrows():
            # slower associates are a bit more likely to be audited, but coverage is never complete
            p_audit = 0.45 + (0.25 if a.base_cycle > 14 else 0)
            if rng.random() > p_audit:
                continue
            day = start + timedelta(days=(w - 1) * 7 + int(rng.integers(0, 5)))
            ts = datetime.combine(day, datetime.min.time()) + timedelta(hours=SHIFT_START + float(rng.uniform(0.5, 9)))
            row = {"audit_id": f"AUD-{w:02d}-{len(rows):05d}", "created_at": ts.strftime("%Y-%m-%d %H:%M:%S"),
                   "week": w, "auditor": rng.choice(AUDITORS), "login": a.login}
            for k in CHECKS:
                fail_p = 0.72 if k == a.weakness else 0.04
                row[k] = "No" if rng.random() < fail_p else "Yes"
            rows.append(row)
    return pd.DataFrame(rows)


def make_shift_data(rng, roster, days) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Timecard segments plus per-minute scan activity, with planted mismatches."""
    seg_rows, act_rows = [], []
    anomalies = ["unrecorded_meal", "short_meal", "late_meal", "activity_in_meal", "idle_gap", "off_clock"]
    for d in days:
        for login in roster.login:
            start = datetime.combine(d, datetime.min.time()) + timedelta(hours=SHIFT_START, minutes=int(rng.integers(-3, 4)))
            end = start + timedelta(hours=SHIFT_HOURS)
            meal_start = start + timedelta(minutes=int(rng.integers(200, 285)))
            meal_len = 30
            anomaly = rng.choice(anomalies) if rng.random() < 0.22 else None

            actual_break = (meal_start, meal_start + timedelta(minutes=meal_len))
            punched_meal = actual_break
            idle_gap = None
            if anomaly == "short_meal":
                meal_len = int(rng.integers(15, 25))
                actual_break = punched_meal = (meal_start, meal_start + timedelta(minutes=meal_len))
            elif anomaly == "late_meal":
                meal_start = start + timedelta(minutes=int(rng.integers(320, 380)))
                actual_break = punched_meal = (meal_start, meal_start + timedelta(minutes=30))
            elif anomaly == "unrecorded_meal":
                punched_meal = None
            elif anomaly == "activity_in_meal":
                # they took the break 90 minutes earlier than the timecard says
                actual_break = (meal_start - timedelta(minutes=90), meal_start - timedelta(minutes=60))
            elif anomaly == "idle_gap":
                g = start + timedelta(minutes=int(rng.integers(400, 520)))
                idle_gap = (g, g + timedelta(minutes=int(rng.integers(22, 40))))

            if punched_meal:
                seg_rows += [
                    {"login": login, "shift_date": d.isoformat(), "segment_type": "work", "start": start, "end": punched_meal[0]},
                    {"login": login, "shift_date": d.isoformat(), "segment_type": "meal", "start": punched_meal[0], "end": punched_meal[1]},
                    {"login": login, "shift_date": d.isoformat(), "segment_type": "work", "start": punched_meal[1], "end": end},
                ]
            else:
                seg_rows.append({"login": login, "shift_date": d.isoformat(), "segment_type": "work", "start": start, "end": end})

            act_end = end + timedelta(minutes=12) if anomaly == "off_clock" else end
            t = start + timedelta(minutes=4)
            while t < act_end - timedelta(minutes=2):
                in_break = actual_break[0] <= t < actual_break[1]
                in_gap = idle_gap and idle_gap[0] <= t < idle_gap[1]
                if not in_break and not in_gap and rng.random() > 0.03:
                    act_rows.append({"login": login, "minute": t, "units": int(rng.integers(2, 7))})
                t += timedelta(minutes=1)

    segs = pd.DataFrame(seg_rows)
    for c in ("start", "end"):
        segs[c] = segs[c].dt.strftime("%Y-%m-%d %H:%M")
    act = pd.DataFrame(act_rows)
    act["minute"] = act["minute"].dt.strftime("%Y-%m-%d %H:%M")
    return segs, act


def generate(out_dir: str | Path, seed: int = 7, n_associates: int = 60, n_weeks: int = 4) -> Path:
    rng = np.random.default_rng(seed)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    weeks = list(range(1, n_weeks + 1))

    roster = make_roster(rng, n_associates)
    profiles = _latent_profiles(rng, roster)
    prod = make_productivity(rng, roster, profiles, weeks)
    audits = make_audits(rng, roster, profiles, weeks)
    last_week_start = date(2026, 6, 29) + timedelta(days=(n_weeks - 1) * 7)
    segs, act = make_shift_data(rng, roster, [last_week_start + timedelta(days=i) for i in range(2)])

    # File names deliberately vary, like real exports do. The pipeline finds them by their columns.
    roster.to_csv(out / "employee_list_export.csv", index=False)
    prod.to_csv(out / "productivity_by_week.csv", index=False)
    audits.to_excel(out / "audit_results.xlsx", index=False)
    segs.to_csv(out / "timecard_segments.csv", index=False)
    act.to_csv(out / "scan_activity_by_minute.csv.gz", index=False, compression="gzip")
    return out
