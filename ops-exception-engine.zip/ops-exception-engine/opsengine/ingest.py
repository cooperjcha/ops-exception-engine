"""Find and load input files by what's inside them, not what they're named.

Real exports arrive as `export(3).csv`, `results_by_audit(2).xlsx` and so on. Instead of
hard-coding names, each file's header row is compared against a column signature.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from .config import CHECKS

SIGNATURES: dict[str, set[str]] = {
    "roster": {"login", "name", "manager", "status"},
    "productivity": {"week", "login", "units", "hours", "avg_cycle_sec"},
    "audits": {"audit_id", "login", "week", *CHECKS},
    "timecards": {"login", "shift_date", "segment_type", "start", "end"},
    "activity": {"login", "minute", "units"},
}
REQUIRED = {"roster", "productivity"}
SUPPORTED = (".csv", ".gz", ".xlsx", ".xls")


@dataclass
class Inputs:
    frames: dict[str, pd.DataFrame] = field(default_factory=dict)
    sources: dict[str, str] = field(default_factory=dict)
    skipped: list[str] = field(default_factory=list)

    def __getitem__(self, kind: str) -> pd.DataFrame:
        return self.frames[kind]

    def has(self, kind: str) -> bool:
        return kind in self.frames


def _read_header(path: Path) -> set[str]:
    if path.suffix in (".xlsx", ".xls"):
        cols = pd.read_excel(path, nrows=0).columns
    else:
        cols = pd.read_csv(path, nrows=0).columns
    return {str(c).strip().lower() for c in cols}


def _read(path: Path) -> pd.DataFrame:
    df = pd.read_excel(path) if path.suffix in (".xlsx", ".xls") else pd.read_csv(path)
    df.columns = [str(c).strip().lower() for c in df.columns]
    if "login" in df.columns:
        df["login"] = df["login"].astype(str).str.strip().str.lower()
    return df


def classify(columns: set[str]) -> str | None:
    """Return the most specific signature the columns satisfy."""
    matches = [k for k, sig in SIGNATURES.items() if sig <= columns]
    return max(matches, key=lambda k: len(SIGNATURES[k])) if matches else None


def discover(folder: str | Path, log=print) -> Inputs:
    folder = Path(folder)
    inputs = Inputs()
    files = sorted(p for p in folder.iterdir() if p.is_file() and p.name.endswith(SUPPORTED))
    # newest file wins when two files match the same kind
    for path in sorted(files, key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            kind = classify(_read_header(path))
        except Exception as exc:  # unreadable file: note it and keep going
            inputs.skipped.append(f"{path.name} (unreadable: {exc})")
            continue
        if kind is None:
            inputs.skipped.append(f"{path.name} (no matching column signature)")
        elif kind in inputs.frames:
            inputs.skipped.append(f"{path.name} (older duplicate {kind} file)")
        else:
            inputs.frames[kind] = _read(path)
            inputs.sources[kind] = path.name

    log(f"Scanning {folder} for input files...")
    for kind in SIGNATURES:
        found = inputs.sources.get(kind, "NOT FOUND")
        log(f"  {kind:<13} {found}")
    for s in inputs.skipped:
        log(f"  skipped       {s}")
    missing = REQUIRED - inputs.frames.keys()
    if missing:
        raise FileNotFoundError(f"Missing required input(s): {', '.join(sorted(missing))}")
    return inputs


def data_quality(inputs: Inputs) -> list[dict]:
    """Cross-file checks. Each issue is something that would silently corrupt a VLOOKUP-style join."""
    issues: list[dict] = []
    roster, prod = inputs["roster"], inputs["productivity"]
    roster_logins = set(roster.login)

    dupes = prod[prod.duplicated(["week", "login"], keep=False)]
    for (wk, login), _ in dupes.groupby(["week", "login"]):
        issues.append({"check": "Duplicate productivity row", "login": login,
                       "detail": f"Week {wk} appears more than once; kept the first row."})

    for login in sorted(set(prod.login) - roster_logins):
        issues.append({"check": "Login not on roster", "login": login,
                       "detail": "Has productivity hours but no roster record, so manager and name are unknown."})

    inactive = roster[roster.status.str.lower() != "active"]
    latest = prod.week.max()
    for _, r in inactive[inactive.login.isin(prod[prod.week == latest].login)].iterrows():
        issues.append({"check": "Inactive associate with hours", "login": r.login,
                       "detail": f"Roster status is {r.status} but hours were logged in week {latest}."})

    if inputs.has("audits"):
        a = inputs["audits"]
        for login in sorted(set(a.login) - roster_logins):
            issues.append({"check": "Audit for unknown login", "login": login,
                           "detail": "Audit can't be matched to a roster record."})
        bad = a[~a[list(CHECKS)].isin(["Yes", "No"]).all(axis=1)]
        for _, r in bad.iterrows():
            issues.append({"check": "Malformed audit answer", "login": r.login,
                           "detail": f"{r.audit_id} has a checklist value other than Yes/No."})
    return issues
