"""Write results two ways: an Excel tracker for people who live in spreadsheets, and a JSON
payload for the static web dashboard in docs/."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule, ColorScaleRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HEAD_FILL = PatternFill("solid", fgColor="1F2E4A")
HEAD_FONT = Font(name="Arial", bold=True, color="FFFFFF")
BODY_FONT = Font(name="Arial", size=10)
RED = PatternFill("solid", fgColor="F6D3CF")
AMBER = PatternFill("solid", fgColor="FBEBC2")


def _sheet(wb: Workbook, title: str, df: pd.DataFrame, widths: dict[str, int] | None = None):
    ws = wb.create_sheet(title)
    ws.append(list(df.columns))
    for row in df.itertuples(index=False):
        ws.append([", ".join(v) if isinstance(v, list) else v for v in row])
    for c in ws[1]:
        c.fill, c.font = HEAD_FILL, HEAD_FONT
        c.alignment = Alignment(wrap_text=True, vertical="center")
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.font = BODY_FONT
            c.alignment = Alignment(vertical="top", wrap_text=isinstance(c.value, str) and len(c.value) > 40)
    for i, col in enumerate(df.columns, 1):
        ws.column_dimensions[get_column_letter(i)].width = (widths or {}).get(col, max(10, min(len(col) + 4, 22)))
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    return ws


def write_excel(path: Path, week: int, summary: dict, queue: pd.DataFrame, focus: list[dict],
                exceptions: pd.DataFrame, issues: list[dict]) -> None:
    wb = Workbook()
    wb.remove(wb.active)

    q = queue.drop(columns=["focus_key"])
    st = get_column_letter(list(q.columns).index("status") + 1)
    sev = get_column_letter(list(exceptions.columns).index("severity") + 1)
    ws = wb.create_sheet("Summary")
    ws["A1"] = f"Ops Exception Engine: week {week}"
    ws["A1"].font = Font(name="Arial", bold=True, size=14)
    ws["A2"] = "Synthetic demo data. Counts below are live formulas over the other tabs."
    ws["A2"].font = Font(name="Arial", italic=True, size=9, color="666666")
    rows = [
        ("Benchmark cycle time (s, site median)", summary["benchmark_cycle_sec"]),
        ("Flag threshold (s)", summary["flag_threshold_sec"]),
        ("Flagged associates", "=COUNTA('Coaching Queue'!B:B)-1"),
        ("Audited this week", f"=COUNTA('Coaching Queue'!B:B)-1-COUNTIF('Coaching Queue'!{st}:{st},\"No audit\")"),
        ("Audit coverage", "=IFERROR(B6/B5,0)"),
        ("Ready to coach (failed a check)", f"=COUNTIF('Coaching Queue'!{st}:{st},\"Failed checks\")"),
        ("Passed, still slow", f"=COUNTIF('Coaching Queue'!{st}:{st},\"Passed, still slow\")"),
        ("Timecard exceptions", "=COUNTA('Timecard Exceptions'!A:A)-1"),
        ("High-severity timecard exceptions", f"=COUNTIF('Timecard Exceptions'!{sev}:{sev},\"High\")"),
        ("Data quality issues", "=COUNTA('Data Quality'!A:A)-1"),
    ]
    for i, (label, val) in enumerate(rows, start=3):
        ws.cell(i, 1, label).font = BODY_FONT
        c = ws.cell(i, 2, val)
        c.font = Font(name="Arial", size=10, color="000000" if str(val).startswith("=") else "0000FF")
    ws["B7"].number_format = "0%"
    ws.column_dimensions["A"].width, ws.column_dimensions["B"].width = 40, 14
    ws["A15"] = "Blue values are computed by the pipeline; black values are formulas."
    ws["A15"].font = Font(name="Arial", italic=True, size=9, color="666666")

    wq = _sheet(wb, "Coaching Queue", q, {"name": 20, "manager": 18, "action": 60, "failed_checks": 40, "focus_check": 34})
    cyc = get_column_letter(list(q.columns).index("avg_cycle_sec") + 1)
    wq.conditional_formatting.add(f"{cyc}2:{cyc}{len(q) + 1}",
                                  ColorScaleRule(start_type="min", start_color="FBEBC2", end_type="max", end_color="E8867A"))

    f = pd.DataFrame(focus)
    if not f.empty:
        wf = _sheet(wb, "Checklist Failure Rates", f[["check", "flagged_fail_rate", "site_fail_rate"]], {"check": 46})
        for row in wf.iter_rows(min_row=2, min_col=2, max_col=3):
            for c in row:
                c.number_format = "0.0%"

    we = _sheet(wb, "Timecard Exceptions", exceptions, {"detail": 70, "rule": 26, "name": 20, "manager": 18})
    rng = f"{sev}2:{sev}{max(len(exceptions) + 1, 2)}"
    we.conditional_formatting.add(rng, CellIsRule(operator="equal", formula=['"High"'], fill=RED))
    we.conditional_formatting.add(rng,
                                  CellIsRule(operator="equal", formula=['"Medium"'], fill=AMBER))

    _sheet(wb, "Data Quality", pd.DataFrame(issues, columns=["check", "login", "detail"]), {"detail": 70, "check": 30})
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def write_dashboard_data(docs_dir: Path, payload: dict) -> None:
    """Writes dashboard.json (for fetch) and dashboard.js (so index.html also works from file://)."""
    data_dir = docs_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, default=str, separators=(",", ":"))
    (data_dir / "dashboard.json").write_text(text)
    (data_dir / "dashboard.js").write_text(f"window.DASHBOARD_DATA = {text};\n")
