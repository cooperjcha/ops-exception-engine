import pandas as pd
import pytest

from opsengine import coaching, ingest
from opsengine.__main__ import build
from opsengine.config import CHECKS
from opsengine.generate import generate


def test_classify_by_columns_not_filename():
    assert ingest.classify({"login", "name", "manager", "status", "extra"}) == "roster"
    assert ingest.classify({"week", "login", "units", "hours", "avg_cycle_sec"}) == "productivity"
    assert ingest.classify({"login", "minute", "units"}) == "activity"
    assert ingest.classify({"foo", "bar"}) is None


def test_missing_required_input_raises(tmp_path):
    pd.DataFrame({"login": ["a"], "minute": ["2026-01-01 00:00"], "units": [1]}).to_csv(tmp_path / "x.csv", index=False)
    with pytest.raises(FileNotFoundError, match="productivity"):
        ingest.discover(tmp_path, log=lambda *_: None)


def _week(cycles, audits=None):
    roster = pd.DataFrame({"login": list(cycles), "name": list(cycles), "manager": "M", "status": "Active"})
    prod = pd.DataFrame({"week": 1, "login": list(cycles), "units": 1000, "hours": 30.0,
                         "avg_cycle_sec": list(cycles.values()), "idle_pct": 0.1})
    return prod, roster, audits


def _audit(login, fails=()):
    row = {"audit_id": f"A-{login}", "created_at": "2026-07-01 20:00:00", "week": 1, "login": login}
    row.update({k: ("No" if k in fails else "Yes") for k in CHECKS})
    return row


def test_queue_status_and_ordering():
    cycles = {f"a{i}": 10.0 for i in range(10)} | {"slow1": 20.0, "slow2": 18.0, "slow3": 17.0}
    audits = pd.DataFrame([_audit("slow1", fails=["chk_retrieve_2s"]), _audit("slow2")])
    prod, roster, aud = _week(cycles, audits)
    queue, summary = coaching.build_week(prod, roster, aud, 1, {})
    by = queue.set_index("login")
    assert by.loc["slow1", "status"] == "Failed checks"
    assert by.loc["slow1", "focus_check"] == CHECKS["chk_retrieve_2s"]
    assert by.loc["slow2", "status"] == "Passed, still slow"
    assert by.loc["slow3", "status"] == "No audit"
    assert queue.iloc[0].login == "slow1"
    assert summary["benchmark_cycle_sec"] == 10.0


def test_repeat_flags_raise_priority():
    cycles = {f"a{i}": 10.0 for i in range(10)} | {"slow1": 17.0, "slow2": 17.0}
    prod, roster, _ = _week(cycles)
    prod = pd.concat([prod, prod.assign(week=2)])
    history = {"1": {"slow2": {"status": "No audit", "focus": None}}}
    queue, summary = coaching.build_week(prod, roster, None, 2, history)
    by = queue.set_index("login")
    assert by.loc["slow2", "weeks_flagged_in_a_row"] == 2
    assert bool(by.loc["slow2", "repeat_same_reason"]) is True
    assert by.loc["slow2", "priority"] > by.loc["slow1", "priority"]


def test_end_to_end_finds_planted_problems(tmp_path):
    raw = generate(tmp_path / "raw", seed=7)
    payload = build(raw, tmp_path / "out", tmp_path / "docs", None)
    checks = {d["check"] for d in payload["data_quality"]}
    assert {"Login not on roster", "Duplicate productivity row", "Inactive associate with hours"} <= checks
    assert payload["summary"]["flagged"] > 0
    assert payload["exceptions"], "planted timecard anomalies should be detected"
    assert (tmp_path / "out" / "ops_tracker_week04.xlsx").exists()
    assert (tmp_path / "docs" / "data" / "dashboard.json").exists()
