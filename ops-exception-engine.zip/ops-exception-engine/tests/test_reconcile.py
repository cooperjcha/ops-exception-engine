import pandas as pd

from opsengine.reconcile import reconcile

DAY = "2026-07-20"


def ts(hhmm):
    """Night shift: times before noon belong to the next calendar day."""
    t = pd.Timestamp(f"{DAY} {hhmm}")
    return t + pd.Timedelta(days=1) if t.hour < 12 else t


def shift(login="tst", meal=("21:30", "22:00"), start="18:00", end="04:30"):
    rows = []
    if meal:
        rows += [("work", start, meal[0]), ("meal", meal[0], meal[1]), ("work", meal[1], end)]
    else:
        rows += [("work", start, end)]
    return pd.DataFrame([{"login": login, "shift_date": DAY, "segment_type": t, "start": ts(a), "end": ts(b)}
                         for t, a, b in rows])


def activity(login="tst", start="18:04", end="04:28", breaks=()):
    mins = pd.date_range(ts(start), ts(end), freq="min")
    for a, b in breaks:
        mins = mins[(mins < ts(a)) | (mins >= ts(b))]
    return pd.DataFrame({"login": login, "minute": mins, "units": 3})


def rules(tc, act):
    return sorted(reconcile(tc, act).rule.tolist())


def test_clean_shift_has_no_exceptions():
    assert rules(shift(), activity(breaks=[("21:30", "22:00")])) == []


def test_unrecorded_meal_found_from_activity_gap():
    ex = reconcile(shift(meal=None), activity(breaks=[("21:30", "22:00")]))
    assert ex.rule.tolist() == ["Unrecorded meal"]
    assert ex.when.iloc[0] == "21:30-22:00"


def test_missed_meal_when_no_punch_and_no_gap():
    assert rules(shift(meal=None), activity()) == ["Missed meal"]


def test_short_and_late_meal():
    assert rules(shift(meal=("21:30", "21:50")), activity(breaks=[("21:30", "21:50")])) == ["Short meal"]
    assert rules(shift(meal=("23:40", "00:10")), activity(breaks=[("23:40", "00:10")])) == ["Late meal"]


def test_break_taken_at_wrong_time_is_one_linked_exception():
    ex = reconcile(shift(meal=("22:00", "22:30")), activity(breaks=[("20:30", "21:00")]))
    assert ex.rule.tolist() == ["Activity during recorded meal"]
    assert "20:30-21:00" in ex.detail.iloc[0]


def test_unexplained_idle_gap():
    ex = reconcile(shift(), activity(breaks=[("21:30", "22:00"), ("01:00", "01:35")]))
    assert ex.rule.tolist() == ["Unexplained idle gap"]
    assert ex.severity.iloc[0] == "Medium"


def test_activity_after_clock_out():
    assert rules(shift(), activity(end="04:42", breaks=[("21:30", "22:00")])) == ["Activity off the clock"]
